package com.klef.jfsd.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleMcQmakerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleMcQmakerApplication.class, args);
	}

}
